import asyncio, json, sys, random, threading, uuid, os, time, base64, hashlib
from collections import deque
from aiokafka import AIOKafkaConsumer, AIOKafkaProducer
from uuid import uuid4
from cryptography.hazmat.primitives.ciphers.aead import AESGCM



# -------------------------------------------------------------
# ARGUMENTOS
# -------------------------------------------------------------
if len(sys.argv) < 3:
    print("Uso: python EV_CP_E.py <broker_ip:puerto> <puerto_engine>")
    sys.exit(1)

BROKER = sys.argv[1]
ENGINE_PORT = int(sys.argv[2])

# -------------------------------------------------------------
# ESTADO GLOBAL
# -------------------------------------------------------------
CP_ID = None
CP_LOCATION = "Desconocida"
STATUS = "DESCONECTADO"
PRICE = round(random.uniform(0.40, 0.70), 2)
HEALTH = "OK"               # expuesto vía HEARTBEAT local
STOP = asyncio.Event()      # señal para detener carga
CHARGE_TASK = None          # asyncio.Task | None
GROUP_ID  = f"engine-{ENGINE_PORT}"                
CLIENT_ID = f"{GROUP_ID}-{uuid4().hex[:6]}"         # evita colisiones de client.id
# Entrada de usuario (único lector)
INPUT_Q: asyncio.Queue[str] = asyncio.Queue()
PROMPT_FUT: asyncio.Future | None = None

# Buffer de drivers y autorización
AVAILABLE_DRIVERS = deque(maxlen=50)   # [{'driver_id','request_id','cp_id','ts'}]
PENDING_AUTH = None                    # {'driver_id','request_id','cp_id'}

END_REASON = None
STOP_CENTRAL = False

# -------------------------------------------------------------
# UTILIDADES DE TECLADO 
# -------------------------------------------------------------
def stdin_reader(loop: asyncio.AbstractEventLoop):
    """Único lector de stdin. Con esto evitamos bloqueos en el loop."""
    global PROMPT_FUT
    while True:
        try:
            line = input()
        except EOFError:
            break
        line = (line or "").strip()
        fut = PROMPT_FUT
        if fut is not None and not fut.done():
            loop.call_soon_threadsafe(fut.set_result, line)
        else:
            asyncio.run_coroutine_threadsafe(INPUT_Q.put(line), loop)

async def ask(prompt: str) -> str:
    """Muestra un prompt y espera una respuesta de teclado sin bloquear el loop."""
    global PROMPT_FUT
    print(prompt, end="", flush=True)
    PROMPT_FUT = asyncio.get_running_loop().create_future()
    try:
        resp = await PROMPT_FUT
        print("")  # salto de línea después de la respuesta
        return resp
    finally:
        PROMPT_FUT = None

# -------------------------------------------------------------
# CIFRADO AES-GCM
# -------------------------------------------------------------
def _key_file_for(cp_id: str) -> str:
    return f"cp_{cp_id}_secretkey.json"

def load_secret_key_str_for_cp(cp_id: str) -> str:
    key_file = _key_file_for(cp_id)
    if not os.path.exists(key_file):
        raise RuntimeError(f"No hay secret_key para CP {cp_id}. Autentica el monitor primero (opción 3).")
    with open(key_file, "r", encoding="utf-8") as f:
        return json.load(f)["secret_key"]

def derive_aes_key(secret_key_str: str) -> bytes:
    return hashlib.sha256(secret_key_str.encode("utf-8")).digest()

def encrypt_kafka_envelope(cp_id: str, topic: str, plain_obj: dict) -> dict:
    secret_key_str = load_secret_key_str_for_cp(cp_id)
    key = derive_aes_key(secret_key_str)
    aesgcm = AESGCM(key)

    nonce = os.urandom(12)
    ts = int(time.time())

    pt = json.dumps(plain_obj, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

    aad = f"{cp_id}|{ts}|{topic}".encode("utf-8")

    ct = aesgcm.encrypt(nonce, pt, aad)

    return {
        "action": "SECURE",
        "cp_id": cp_id,
        "ts": ts,
        "nonce": base64.b64encode(nonce).decode("ascii"),
        "ciphertext": base64.b64encode(ct).decode("ascii"),
    }


# -------------------------------------------------------------
# KAFKA → CENTRAL
# -------------------------------------------------------------

async def send_status(producer: AIOKafkaProducer, status: str):
    """Publica el estado y, si implica no suministrar, activa STOP para cortar la carga."""
    global STATUS
    STATUS = status
    # ⬇️ si el estado no permite cargar, detén la sesión en curso
    if status.upper() in {"PARADO", "AVERIA", "DESCONECTADO"}:
        STOP.set()
    payload = {"cp_id": CP_ID, "status": status}
    secured_payload = encrypt_kafka_envelope(CP_ID, "cp.status", payload)
    await producer.send_and_wait("cp.status", json.dumps(secured_payload).encode())
    print(f"Estado actualizado: {status}")

# -------------------------------------------------------------
# CARGA (con finalización automática si hay STOP)
# -------------------------------------------------------------
async def start_charging(producer: AIOKafkaProducer):
    global STATUS, CHARGE_TASK, END_REASON, HEALTH, STOP_CENTRAL

    STOP.clear()
    END_REASON = None          
    STATUS = "SUMINISTRANDO"
    await send_status(producer, STATUS)
    print(f"Iniciando carga en {CP_ID} (Precio: {PRICE} €/kWh)")

    kwh = 0.0

    for _ in range(360000):    
        if STOP.is_set():
            break

        kw = round(random.uniform(6.0, 7.5), 2)
        kwh += kw / 3600 * 60 # cada ciclo es 1 minuto simulacion
        amount = round(kwh * PRICE, 2)

        telem = {
            "cp_id": CP_ID,
            "session_id": 1,
            "kw": kw,
            "kwh_total": round(kwh, 3),
            "eur_total": amount
        }
        secured_telem = encrypt_kafka_envelope(CP_ID, "cp.telemetry", telem)
        await producer.send_and_wait("cp.telemetry", json.dumps(secured_telem).encode())
        print(f"{CP_ID}: {kw} kW — {amount:.2f} €")

        try:
            await asyncio.wait_for(STOP.wait(), timeout=1.0)
        except asyncio.TimeoutError:
            pass


    aborted = STOP.is_set() and END_REASON is None
    if STOP_CENTRAL:
        reason = "FINALIZADO_POR_STOP_DE_CENTRAL"
    elif HEALTH == "KO":
        reason = "FINALIZADO_POR_KO_DE_ENGINE"
    elif END_REASON is not None:
        reason = END_REASON
    else:
        reason = "ABORTED" if aborted else "FINISHED"

    end_msg = {
        "cp_id": CP_ID,
        "session_id": 1,
        "kwh": round(kwh, 3),
        "amount_eur": round(kwh * PRICE, 2),
        "reason": reason,
    }
    secured_end_msg = encrypt_kafka_envelope(CP_ID, "cp.session_ended", end_msg)
    await producer.send_and_wait("cp.session_ended", json.dumps(secured_end_msg).encode())

    final_status = "PARADO" if aborted else "ACTIVADO"
    await send_status(producer, final_status)

    print(f"Carga finalizada. reason={reason}, final_status={final_status}")
    print_menu()
    CHARGE_TASK = None

# -------------------------------------------------------------
# MENÚ
# -------------------------------------------------------------
def print_menu():
    print("\n===== MENÚ ENGINE =====")
    print("1) Activarse (health=OK / status=ACTIVADO)")
    print("2) Desactivar (KO)  (health=KO / status=PARADO)")
    print("3) Suministrar a un driver manualmente")
    print("4) Aceptar suministro (si hay autorización pendiente)")
    print("5) Rechazar suministro (si hay autorización pendiente)")
    print("6) Finalizar suministro en curso (si hay)")
    print("=======================\n")

async def menu_loop(producer: AIOKafkaProducer):
    global HEALTH, PENDING_AUTH, CHARGE_TASK, STATUS
    print_menu()
    while True:
        cmd = (await INPUT_Q.get()).strip()
        if cmd == "1":
            HEALTH = "OK"
            if (not STOP_CENTRAL):
                STOP.clear()
                await send_status(producer, "ACTIVADO")
                print("CP ACTIVADO (salud=OK).")
            else:
                await send_status(producer, "PARADO")
                print("CP en estado de salud OK, parado por central.")

        elif cmd == "2":
            HEALTH = "KO"
            STOP.set()                         
            await send_status(producer, "AVERIA")
            print("CP en KO (status AVERIA).")

        elif cmd == "3":
            if not CP_ID:
                print("Aún no está registrado el CP (falta registro del monitor).")
            elif STATUS not in ("ACTIVADO",):
                print(f"CP no disponible (status={STATUS}).")
            elif CHARGE_TASK and not CHARGE_TASK.done():
                print("Ya hay una carga en marcha.")
            else:
                drv = (await ask("Driver ID para suministro manual: ")).strip()
                if not drv:
                    print("Driver ID vacío.")
                else:
                    req_id = "manual-" + uuid.uuid4().hex[:8]
                    payload = {"cp_id": CP_ID, "driver_id": drv, "request_id": req_id}
                    secured_payload = encrypt_kafka_envelope(CP_ID, "engine.start_manual", payload)
                    await producer.send_and_wait("engine.start_manual", json.dumps(secured_payload).encode())
                    print(f"Enviado engine.start_manual: cp={CP_ID} driver={drv} req={req_id}")
                    print("↪ Espera 'central.authorize' y luego usa 4) Aceptar o 5) Rechazar.")

        elif cmd == "4":
            if not PENDING_AUTH or PENDING_AUTH.get("cp_id") != CP_ID:
                print("No hay autorización pendiente para este CP.")
            elif STATUS == "SUMINISTRANDO" or (CHARGE_TASK and not CHARGE_TASK.done()):
                print("ℹYa hay una carga en marcha.")
            else:
                STOP.clear()
                print(f"Aceptando suministro para driver {PENDING_AUTH['driver_id']} ...")
                CHARGE_TASK = asyncio.create_task(start_charging(producer))
                PENDING_AUTH = None

        elif cmd == "5":
            if not PENDING_AUTH or PENDING_AUTH.get("cp_id") != CP_ID:
                print("No hay autorización pendiente para este CP.")
            else:
                reason = "RECHAZADO_POR_ENGINE"
                payload = {
                    "cp_id": PENDING_AUTH["cp_id"],
                    "driver_id": PENDING_AUTH["driver_id"],
                    "request_id": PENDING_AUTH["request_id"],
                    "reason": reason,
                }
                secured_payload = encrypt_kafka_envelope(CP_ID, "engine.reject", payload)
                await producer.send_and_wait("engine.reject", json.dumps(secured_payload).encode())
                print(f"Rechazo enviado a CENTRAL para driver {PENDING_AUTH['driver_id']}.")
                PENDING_AUTH = None
        elif cmd == "6":
            global END_REASON
            if STATUS != "SUMINISTRANDO" or not (CHARGE_TASK and not CHARGE_TASK.done()):
                print("No hay ninguna carga en curso.")
            else:
                END_REASON = "FINALIZADO_CORRECTAMENTE_POR_ENGINE"
                STOP.set()   # solo para salir del bucle
                print("Solicitud de finalización de carga enviada.")

        else:
            print("Opción no válida.")
        print_menu()

# -------------------------------------------------------------
# SOCKET (Monitor ↔ Engine)
# -------------------------------------------------------------
async def handle_monitor_connection(reader: asyncio.StreamReader, writer: asyncio.StreamWriter, producer: AIOKafkaProducer):
    global CP_ID, CP_LOCATION, HEALTH
    try:
        data = await reader.read(4096)
        if not data:
            return
        message = data.decode().strip()

        if message == "PING":
            writer.write(b"OK"); await writer.drain(); return
        if message == "HEARTBEAT":
            writer.write(HEALTH.encode()); await writer.drain(); return

        try:
            payload = json.loads(message)
        except Exception:
            writer.write(b"NACK"); await writer.drain(); return

        # Registro inicial 
        if "cp_id" in payload and "location" in payload:
            CP_ID = payload["cp_id"]
            CP_LOCATION = payload["location"]
            print(f"Recibido ID {CP_ID} y ubicación {CP_LOCATION}")
            writer.write(b"ACK"); await writer.drain()

            # Solo activar si el Engine está sano y NO hay STOP activo
            desired = "ACTIVADO" if (HEALTH == "OK" and not STOP.is_set()) else "PARADO"
            await send_status(producer, desired)
            return



        # Acciones locales
        if "action" in payload:
            action = (payload["action"] or "").upper()
            print(f"Orden local del monitor: {action}")
            if action == "PARAR":
                STOP.set()
                await send_status(producer, "PARADO")
                writer.write(b"OK"); await writer.drain(); return
            elif action == "ACTIVAR":
                STOP.clear()
                await send_status(producer, "ACTIVADO")
                writer.write(b"OK"); await writer.drain(); return
            elif action == "SUMINISTRAR": 
                # Demo local (sin autorización CENTRAL)
                if not (CHARGE_TASK and not CHARGE_TASK.done()):
                    CHARGE_TASK = asyncio.create_task(start_charging(producer))
                writer.write(b"OK"); await writer.drain(); return
            elif action == "KO":
                HEALTH = "KO"
                STOP.set()                         #  detener si estaba cargando
                await send_status(producer, "AVERIA")
                writer.write(b"OK"); await writer.drain(); return
            elif action == "OK":
                HEALTH = "OK"
                STOP.clear()
                writer.write(b"OK"); await writer.drain(); return
            else:
                writer.write(b"NACK"); await writer.drain(); return

        writer.write(b"NACK"); await writer.drain()
    except Exception as e:
        print(f"Error procesando mensaje del monitor: {e}")
    finally:
        try:
            writer.close()
            await writer.wait_closed()
        except Exception:
            pass

async def start_socket_server(producer: AIOKafkaProducer):
    server = await asyncio.start_server(
        lambda r, w: handle_monitor_connection(r, w, producer),
        host="0.0.0.0",
        port=ENGINE_PORT
    )
    addrs = ", ".join(str(sock.getsockname()) for sock in server.sockets or [])
    print(f"Escuchando conexiones del monitor en {addrs}...")
    async with server:
        await server.serve_forever()

# -------------------------------------------------------------
# ESCUCHA A CENTRAL (Kafka)
# -------------------------------------------------------------
async def listen_to_central(consumer: AIOKafkaConsumer, producer: AIOKafkaProducer):
    global CHARGE_TASK, PENDING_AUTH, STATUS, CP_ID, STOP, STOP_CENTRAL
    print("👂 Esperando mensajes de CENTRAL...")
    try:
        async for msg in consumer:
            data = msg.value

            # Drivers que piden este CP (para mostrar en menú)
            if msg.topic == "driver.request":
                if data.get("cp_id") == CP_ID:
                    AVAILABLE_DRIVERS.append({
                        "driver_id": data.get("driver_id"),
                        "request_id": data.get("request_id"),
                        "cp_id": data.get("cp_id"),
                        "ts": asyncio.get_running_loop().time(),
                    })
                continue

            # CENTRAL autoriza este CP para un driver concreto
            if msg.topic == "central.authorize":
                if data.get("cp_id") != CP_ID:
                    continue
                PENDING_AUTH = {
                    "driver_id": data.get("driver_id"),
                    "request_id": data.get("request_id"),
                    "cp_id": data.get("cp_id"),
                }
                print("Autorización recibida para este CP. Usa 4) Aceptar o 5) Rechazar.")
                continue

            # STOP / RESUME desde CENTRAL
            if msg.topic == "central.command":
                action = (data.get("action") or "").upper()
                target = data.get("cp_id", "ALL")

                # 1) Si todavía no sé qué CP soy, ignoro los comandos
                if CP_ID is None:
                    # aún no he recibido el registro del monitor
                    continue

                # 2) Si el comando no es para mí ni es ALL → ignorar
                if target not in ("ALL", CP_ID):
                    continue

                if action == "STOP":
                    STOP.set()
                    STOP_CENTRAL = True
                    # Si estoy suministrando, dejo que start_charging cierre sesión 
                    if STATUS == "SUMINISTRANDO" and CHARGE_TASK and not CHARGE_TASK.done():
                        print(f"Carga detenida por CENTRAL en {CP_ID}")
                    else:
                        # Si no estaba cargando, solo pongo en PARADO si no lo estaba ya
                        if STATUS != "PARADO":
                            await send_status(producer, "PARADO")
                        print(f"(Aviso) STOP recibido en {CP_ID}")

                elif action == "RESUME":
                    STOP.clear()
                    STOP_CENTRAL = False
                    # Solo mandamos ACTIVADO si no lo estaba ya
                    if STATUS != "ACTIVADO":
                        await send_status(producer, "ACTIVADO")
                        print(f"CP {CP_ID} marcado como ACTIVADO por CENTRAL")

                continue  

    except asyncio.CancelledError:
        pass

# -------------------------------------------------------------
# MAIN
# -------------------------------------------------------------
async def main():
    producer = AIOKafkaProducer(
        bootstrap_servers=BROKER,
        client_id=CLIENT_ID,
        request_timeout_ms=30000,
    )
    consumer = AIOKafkaConsumer(
        "driver.request", "central.authorize", "central.command",
        bootstrap_servers=BROKER,
        value_deserializer=lambda b: json.loads(b.decode()),
        group_id=GROUP_ID,
        client_id=CLIENT_ID,
        auto_offset_reset="latest",
        enable_auto_commit=False,             
        session_timeout_ms=20000,              
        heartbeat_interval_ms=3000,
        request_timeout_ms=30000,
        max_poll_interval_ms=300000,
    )

    await producer.start()
    await consumer.start()
    print(f"EV_CP_E conectado a Kafka {BROKER}")
    print(f"Puerto del Engine para monitor: {ENGINE_PORT}")

    # Lanzar lector de teclado y tareas concurrentes
    loop = asyncio.get_running_loop()
    threading.Thread(target=stdin_reader, args=(loop,), daemon=True).start()

    socket_task = asyncio.create_task(start_socket_server(producer))
    central_task = asyncio.create_task(listen_to_central(consumer, producer))
    menu_task   = asyncio.create_task(menu_loop(producer))

    try:
        await asyncio.gather(socket_task, central_task, menu_task)
    except KeyboardInterrupt:
        print("\nInterrumpido por teclado. Cerrando…")
    finally:
        STOP.set()
        for t in (socket_task, central_task, menu_task):
            t.cancel()
            try:
                await t
            except asyncio.CancelledError:
                pass
        await consumer.stop()
        await producer.stop()

# -------------------------------------------------------------
# EJECUCIÓN
# -------------------------------------------------------------
if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print(f"\nEngine en puerto {ENGINE_PORT} detenido por el usuario.")
